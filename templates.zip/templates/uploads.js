// // Fetch files from Flask API
//   fetch('http://localhost:5000/listfiles')
//     .then(response => response.json())
//     .then(files => {
//       const wrapper = document.getElementById('filesWrapper');

//       if (files.length === 0) {
//         wrapper.innerHTML = '<p>No files found.</p>';
//         return;
//       }

//       files.forEach(file => {
//         const fileDiv = document.createElement('div');
//         fileDiv.className = 'file-container';

//         const fileSpan = document.createElement('span');
//         fileSpan.textContent = file;

//         // Create menu container
//         const menu = document.createElement('div');
//         menu.className = 'menu-container';

//         const dots = document.createElement('div');
//         dots.className = 'dots';
//         dots.textContent = '⋮';

//         const options = document.createElement('div');
//         options.className = 'menu-options';

//         const btn = document.createElement('button');
//         btn.textContent = 'view';
//         btn.onclick = () => {
//           // Example action: toggle selection style
//           fileDiv.classList.toggle('selected');
//           alert(`Selected: ${file}`);
//         };

//         options.appendChild(btn);
//         menu.appendChild(dots);
//         menu.appendChild(options);

//         fileDiv.appendChild(fileSpan);
//         fileDiv.appendChild(menu);
//         wrapper.appendChild(fileDiv);
//       });
//     })
//     .catch(error => {
//       console.error('Error fetching files:', error);
//       document.getElementById('filesWrapper').innerText = 'Failed to load file list.';
//     });


// btn.onclick = () => {
//   fileDiv.classList.toggle('selected');

//   fetch(`http://localhost:5000/preview/${file}`)
//     .then(res => res.json())
//     .then(data => {
//       if (data.message) {
//       } else if (data.error) {
//         alert(`Error: ${data.error}`);
//       }
//     })
//     .catch(err => {
//       console.error('API error:', err);
//       alert('An error occurred while processing the file.');
//     });
// };

// Fetch files from Flask API
fetch('http://localhost:5000/listfiles')
  .then(response => response.json())
  .then(files => {
    const wrapper = document.getElementById('filesWrapper');

    if (files.length === 0) {
      wrapper.innerHTML = '<p>No files found.</p>';
      return;
    }

    files.forEach(file => {
      const fileDiv = document.createElement('div');
      fileDiv.className = 'file-container';

      const fileSpan = document.createElement('span');
      fileSpan.textContent = file;

      // Create menu container
      const menu = document.createElement('div');
      menu.className = 'menu-container';

      const dots = document.createElement('div');
      dots.className = 'dots';
      dots.textContent = '⋮';

      const options = document.createElement('div');
      options.className = 'menu-options';

      const btn = document.createElement('button');
      btn.textContent = 'View';

btn.onclick = () => {
  fetch(`http://localhost:5000/preview/${file}`)
    .then(res => res.json())
    .then(data => {
      const previewDiv = document.getElementById('previewContainer');
      if (data.text) {
        previewDiv.style.display = 'block';
        previewDiv.innerText = data.text; // or innerHTML if you format text
      } else if (data.error) {
        previewDiv.style.display = 'block';
        previewDiv.innerText = `❌ Error: ${data.error}`;
      }
    })
    .catch(err => {
      console.error('API error:', err);
      alert('An error occurred while processing the file.');
    });
};
      

      options.appendChild(btn);
      menu.appendChild(dots);
      menu.appendChild(options);

      fileDiv.appendChild(fileSpan);
      fileDiv.appendChild(menu);
      wrapper.appendChild(fileDiv);
    });
  })
  .catch(error => {
    console.error('Error fetching files:', error);
    document.getElementById('filesWrapper').innerText = 'Failed to load file list.';
  });
