
  function showUploadPopup() {
  const popup = document.getElementById('uploadPopup');
  popup.style.display = 'flex';
}

function redirectToHome() {
  // Hide popup first
  document.getElementById('uploadPopup').style.display = 'none';
  // Redirect or reload home page
  window.location.href = 'index.html'; // Or use location.reload();
}