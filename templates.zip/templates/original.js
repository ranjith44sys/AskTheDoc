
let selectedFilename = null;


fetch('http://localhost:5000/listfiles')
  .then(response => response.json())
  .then(files => {
    const wrapper = document.getElementById('filesWrapper');

    if (files.length === 0) {
      wrapper.innerHTML = '<p>No files found.</p>';
      return;
    }

    files.forEach(file => {
      const fileDiv = document.createElement('div');
      fileDiv.className = 'file-container';

      const fileSpan = document.createElement('span');
      fileSpan.textContent = file;

      // Create menu container
      const menu = document.createElement('div');
      menu.className = 'menu-container';

      const dots = document.createElement('div');
      dots.className = 'dots';
      dots.textContent = '⋮';

      const options = document.createElement('div');
      options.className = 'menu-options';

      // view btn
      const viewbtn = document.createElement('button');
      viewbtn.textContent = 'view';
      viewbtn.onclick = () =>{
        window.location.href ='uploads.html';
      }
      // Select Button
      const selectBtn = document.createElement('button');
      selectBtn.textContent = 'Select';
      selectBtn.onclick = () => {
        fileDiv.classList.toggle('selected');
        selectedFilename = file;  // store the selected filename


fetch(`http://localhost:5000/show/${file}`)
  .then(async res => {
    const contentType = res.headers.get("Content-Type");

    if (!res.ok) {
      const text = await res.text(); // Read raw error message (e.g. HTML)
      throw new Error(`Server responded with ${res.status}: ${text}`);
    }

    if (contentType && contentType.includes("application/json")) {
      return res.json();
    } else {
      throw new Error("❌ Response is not valid JSON.");
    }
  })
  .then(data => {
    if (data.message) {
      alert(`✅ Success: ${data.message}`);
    } else if (data.error) {
      alert(`❌ Error: ${data.error}`);
    }
  })
  .catch(err => {
    console.error('API error:', err);
    alert(`❌ An error occurred: ${err.message}`);
  });

};

// Delete Button
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Delete';
      deleteBtn.onclick = () => {
        if (!confirm(`Are you sure you want to delete "${file}"?`)) return;

        fetch(`http://localhost:5000/delete/${file}`, {
          method: 'DELETE'
        })
          .then(res => res.json())
          .then(data => {
            if (data.message) {
              alert(`🗑️ ${data.message}`);
              wrapper.removeChild(fileDiv); // Remove from UI
            } else if (data.error) {
              alert(`❌ Error: ${data.error}`);
            }
          })
          .catch(err => {
            console.error('Delete API error:', err);
            alert('❌ Failed to delete the file.');
          });
      };

      // Append buttons
      options.appendChild(viewbtn);
      options.appendChild(selectBtn);
      options.appendChild(deleteBtn);
      menu.appendChild(dots);
      menu.appendChild(options);

      fileDiv.appendChild(fileSpan);
      fileDiv.appendChild(menu);
      wrapper.appendChild(fileDiv);
    });
  })
  .catch(error => {
    console.error('Error fetching files:', error);
    document.getElementById('filesWrapper').innerText = 'No Files are uploaded';
  });


// function handleEnter(event) {
//     if (event.key === 'Enter' && !event.shiftKey) {
//         event.preventDefault();
//         sendMessage();
//     }
// }

// function sendMessage() {
//     const input = document.getElementById('chatInput');
//     const message = input.value.trim();
//     if (message === '') return;

//     addMessage(message, 'user');
//     input.value = '';
//     showTypingIndicator();

//     if (!selectedFilename) {
//         hideTypingIndicator();
//         addMessage("⚠️ Please select a file first.", 'agent');
//         return;
//     }

//     fetch(`http://localhost:5000/search?filename=${encodeURIComponent(selectedFilename)}&query=${encodeURIComponent(message)}`)
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error(`HTTP ${response.status} - ${response.statusText}`);
//             }
//             return response.json();
//         })
//         .then(data => {
//             hideTypingIndicator();
//             console.log("Response data:", data);

//             if (data.error) {
//                 addMessage("❌ Error: " + data.error, 'agent');
//             } else if (!Array.isArray(data)) {
//                 addMessage("⚠️ Unexpected response format from server.", 'agent');
//                 console.error("Expected array but got:", data);
//             } else if (data.length === 0) {
//                 addMessage("⚠️ No results found for your query.", 'agent');
//             } else {
//                 const formatted = data.map(item => `
//                     📄 <strong>${item.filename}</strong> (Page ${item.page})<br/>
//                     "${item.text}"<br/>
//                     <em>Relevance: ${item.distance.toFixed(4)}</em>
//                 `).join('<hr/>');
//                 addMessage(formatted, 'agent');
//             }
//         })
//         .catch(error => {
//             hideTypingIndicator();
//             console.error("Search error:", error);
//             addMessage("⚠️ An error occurred while contacting the server.", 'agent');
//         });
// }


// function addMessage(text, sender) {
//     const messagesContainer = document.getElementById('chatMessages');
//     const messageDiv = document.createElement('div');
//     messageDiv.className = `message ${sender}-message`;

//     const now = new Date();
//     const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

//     messageDiv.innerHTML = `
//         <div class="message-content">${text}</div>
//         <div class="message-time">${timeString}</div>
//     `;

//     messagesContainer.appendChild(messageDiv);
//     messagesContainer.scrollTop = messagesContainer.scrollHeight;
// }

// function showTypingIndicator() {
//     const messagesContainer = document.getElementById('chatMessages');
//     const typingDiv = document.createElement('div');
//     typingDiv.className = 'typing-indicator';
//     typingDiv.id = 'typingIndicator';
//     typingDiv.innerHTML = `
//         <div class="typing-dots">
//             <span></span><span></span><span></span>
//         </div>
//     `;
//     messagesContainer.appendChild(typingDiv);
//     messagesContainer.scrollTop = messagesContainer.scrollHeight;
// }

// function hideTypingIndicator() {
//     const typingIndicator = document.getElementById('typingIndicator');
//     if (typingIndicator) typingIndicator.remove();
// }

// // Auto-resize chat input
// document.addEventListener('DOMContentLoaded', function () {
//     const chatInput = document.getElementById('chatInput');
//     if (chatInput) {
//         chatInput.addEventListener('input', function () {
//             this.style.height = 'auto';
//             this.style.height = Math.min(this.scrollHeight, 100) + 'px';
//         });
//     }
// });

// function clearChat() {
//     const messagesContainer = document.getElementById('chatMessages');
//     messagesContainer.innerHTML = `
//         <div class="message agent-message">
//             <div class="message-content">Hello! How can I help you today?</div>
//             <div class="message-time">Just now</div>
//         </div>
//     `;
// }

// function exportChat() {
//     const messages = document.querySelectorAll('.message');
//     let chatLog = 'Chat Export\n' + '='.repeat(20) + '\n\n';

//     messages.forEach(message => {
//         const content = message.querySelector('.message-content').textContent;
//         const time = message.querySelector('.message-time').textContent;
//         const sender = message.classList.contains('user-message') ? 'You' : 'Assistant';
//         chatLog += `[${time}] ${sender}: ${content}\n\n`;
//     });

//     const blob = new Blob([chatLog], { type: 'text/plain' });
//     const url = URL.createObjectURL(blob);
//     const a = document.createElement('a');
//     a.href = url;
//     a.download = 'chat-export.txt';
//     document.body.appendChild(a);
//     a.click();
//     document.body.removeChild(a);
//     URL.revokeObjectURL(url);
// }
function handleEnter(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    if (message === '') return;

    addMessage(escapeHtml(message), 'user');
    input.value = '';
    showTypingIndicator();

    if (!selectedFilename) {
        hideTypingIndicator();
        addMessage("⚠️ Please select a file first.", 'agent');
        return;
    }

    fetch(`http://localhost:5000/search?filename=${encodeURIComponent(selectedFilename)}&query=${encodeURIComponent(message)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP ${response.status} - ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            hideTypingIndicator();
            console.log("Response data:", data);

            if (data.error) {
                addMessage("❌ Error: " + escapeHtml(data.error), 'agent');
                return;
            }

            if (!data.results || !Array.isArray(data.results)) {
                addMessage("⚠️ Unexpected response format from server.", 'agent');
                console.error("Expected 'results' array but got:", data);
                return;
            }

            if (data.results.length === 0) {
                addMessage("⚠️ No results found for your query.", 'agent');
                return;
            }

            const formattedResults = data.results.map(item => `
                📄 <strong>${escapeHtml(item.filename)}</strong> (Page ${item.page})<br/>
                "${escapeHtml(item.text)}"<br/>
                <em>Relevance: ${item.distance.toFixed(4)}</em>
            `).join('<hr/>');

            addMessage(formattedResults, 'agent');

            // Show the LLM answer if it's valid and not an error string
            if (data.llm_answer && data.llm_answer !== "Error generating answer") {
                addMessage(`<strong>Answer:</strong> ${escapeHtml(data.llm_answer)}`, 'agent');
            } else if (data.llm_answer === "Error generating answer") {
                addMessage("⚠️ Unable to generate an answer at the moment.", 'agent');
            }
        })
        .catch(error => {
            hideTypingIndicator();
            console.error("Search error:", error);
            addMessage("⚠️ An error occurred while contacting the server.", 'agent');
        });
}

// Escape HTML to prevent injection in chat messages
function escapeHtml(text) {
    const map = {
        '&': "&amp;",
        '<': "&lt;",
        '>': "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function addMessage(text, sender) {
    const messagesContainer = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;

    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    messageDiv.innerHTML = `
        <div class="message-content">${text}</div>
        <div class="message-time">${timeString}</div>
    `;

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function showTypingIndicator() {
    const messagesContainer = document.getElementById('chatMessages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'typing-indicator';
    typingDiv.id = 'typingIndicator';
    typingDiv.innerHTML = `
        <div class="typing-dots">
            <span></span><span></span><span></span>
        </div>
    `;
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function hideTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) typingIndicator.remove();
}

// Auto-resize chat input
document.addEventListener('DOMContentLoaded', function () {
    const chatInput = document.getElementById('chatInput');
    if (chatInput) {
        chatInput.addEventListener('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        });
    }
});

function clearChat() {
    const messagesContainer = document.getElementById('chatMessages');
    messagesContainer.innerHTML = `
        <div class="message agent-message">
            <div class="message-content">Hello! How can I help you today?</div>
            <div class="message-time">Just now</div>
        </div>
    `;
}

function exportChat() {
    const messages = document.querySelectorAll('.message');
    let chatLog = 'Chat Export\n' + '='.repeat(20) + '\n\n';

    messages.forEach(message => {
        const content = message.querySelector('.message-content').textContent;
        const time = message.querySelector('.message-time').textContent;
        const sender = message.classList.contains('user-message') ? 'You' : 'Assistant';
        chatLog += `[${time}] ${sender}: ${content}\n\n`;
    });

    const blob = new Blob([chatLog], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chat-export.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}
