// const upload_button = document.getElementById('Upload');

// upload_button.addEventListener("click", async function () {
//     const file_input = document.getElementById('pdfInput');
//     const file = file_input.files[0];
    
//     const formData = new FormData()
//     formData.append('pdf',file)

//     fetch('http://127.0.0.1:5000/upload-file',
//         { method :'POST',
//           body : formData,
//          })
//          .then(response => response.json())
//          .then(result => {
//             console.log('success:',result)
//             if (file.name) {
//             addFileToList(file.name);
//         }
//          })
//          .catch(error =>{
//             console.error('error:',error)
//          })
//     })

//  function addFileToList(filename) {
//     const itemDiv = document.createElement('div');
//     itemDiv.className = 'pdf-item';

//     const nameSpan = document.createElement('span');
//     nameSpan.className = 'pdf-name';
//     nameSpan.textContent = filename;

//     const selectbtn = document.createElement('button');
//     selectbtn.className = 'select-btn';
//     selectbtn.textContent = 'Select file'

//     const deleteBtn = document.createElement('button');
//     deleteBtn.className = 'delete-btn';
//     deleteBtn.textContent = 'Delete';

//     deleteBtn.addEventListener('click', async () => {
//         try {
//             const res = await fetch(`http://127.0.0.1:5000/delete/${filename}`, {
//                 method: 'DELETE'
//             });
//             const data = await res.json();

//             if (res.ok) {
//                 itemDiv.remove();
//             } else {
//                 alert(data.error || 'Delete failed.');
//             }
//         } catch (err) {
//             console.error('Delete error:', err);
//         }
//     });

//     itemDiv.appendChild(nameSpan);
//     itemDiv.appendChild(selectbtn);
//     itemDiv.appendChild(deleteBtn);
//     pdfList.appendChild(itemDiv);
    

//     const selectBtn = document.createElement('button');
//       selectBtn.textContent = 'Select';
//       selectBtn.onclick = () => {
//         fileDiv.classList.toggle('selected');

//         fetch(`http://localhost:5000/show/${file}`)
//           .then(res => res.json())
//           .then(data => {
//             if (data.message) {
//               alert(`✅ Success: ${data.message}`);
//               showUploadPopup();

//             } 
//            else if (data.error) {
//               alert(`❌ Error: ${data.error}`);
//             }
//           })
//           .catch(err => {
//             console.error('API error:', err);
//             alert('❌ An error occurred while processing the file.');
//           });
//       };
//       function showUploadPopup() {
//   const popup = document.getElementById('uploadPopup');
//   popup.style.display = 'flex';
// }

// function redirectToHome() {
//   // Hide popup first
//   document.getElementById('uploadPopup').style.display = 'none';
//   // Redirect or reload home page
//   window.location.href = 'index.html'; // Or use location.reload();
// }

// }

document.addEventListener("DOMContentLoaded", () => {
  const uploadButton = document.getElementById('Upload');

  uploadButton.addEventListener("click", async () => {
    const fileInput = document.getElementById('pdfInput');
    const file = fileInput.files[0];
    
    if (!file) return alert('Please select a file');

    const formData = new FormData();
    formData.append('pdf', file);

    fetch('http://127.0.0.1:5000/upload-file', {
      method: 'POST',
      body: formData,
    })
    .then(response => response.json())
    .then(result => {
      console.log('Upload response:', result);
      if (result.message) {
        addFileToList(file.name);
        showUploadPopup(); // ✅ Show popup on success
      } else {
        alert(result.error || 'Upload failed.');
      }
    })
    .catch(error => {
      console.error('Upload error:', error);
      alert('An error occurred while uploading.');
    });
  });

  function addFileToList(filename) {
    const pdfList = document.getElementById('pdfList');

    const itemDiv = document.createElement('div');
    itemDiv.className = 'pdf-item';

    const nameSpan = document.createElement('span');
    nameSpan.className = 'pdf-name';
    nameSpan.textContent = filename;

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = 'Delete';

    deleteBtn.addEventListener('click', async () => {
      try {
        const res = await fetch(`http://127.0.0.1:5000/delete/${filename}`, {
          method: 'DELETE'
        });
        const data = await res.json();

        if (res.ok) {
          itemDiv.remove();
        } else {
          alert(data.error || 'Delete failed.');
        }
      } catch (err) {
        console.error('Delete error:', err);
      }
    });

    itemDiv.appendChild(nameSpan);
    itemDiv.appendChild(deleteBtn);
    pdfList.appendChild(itemDiv);
  }

  function showUploadPopup() {
    const popup = document.getElementById('uploadPopup');
    if (popup) {
      popup.style.display = 'flex';
    } else {
      console.error('Popup element not found.');
    }
  }

  window.redirectToHome = function () {
    document.getElementById('uploadPopup').style.display = 'none';
    window.location.href = 'orginal.html';
  };
});
